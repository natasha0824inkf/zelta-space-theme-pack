#!/usr/bin/env bash
# Zelta welcome banner — shows on terminal startup
# Usage: add this line to ~/.bashrc or ~/.zshrc:
#   source /path/to/zelta-banner.sh

_G='\033[38;2;245;196;0m'   # Zelta gold  #F5C400
_D='\033[38;2;201;162;39m'  # muted gold  #C9A227
_N='\033[38;2;36;48;68m'    # Zelta navy  #243044
_R='\033[0m'

printf "\n"
printf "  ${_G}  ╔══════════════════════════════════╗${_R}\n"
printf "  ${_G}  ║  ✦  Z E L T A                   ║${_R}\n"
printf "  ${_D}  ║  Perfect backups, powered by ZFS ║${_R}\n"
printf "  ${_D}  ║  zelta.space                     ║${_R}\n"
printf "  ${_G}  ╚══════════════════════════════════╝${_R}\n"
printf "\n"
